-There may be some inaccuracies, please take that into consideration.

-Hyrule Field is ommitted due to taking up 22 sequence slots on it's own.

-Fire Temple (v1.2) is missing instruments that are exclusive to OoT v1.2, the sequence is included if anyone wishes to adjust it.

-Fire Temple (v1.0) is missing.

-All songs related to the End Credits are not shuffled in OoTR, as such these sequences are not included.

-When choosing "Random(Custom Only)" for Fanfare Shuffle in OoTR, please be aware that the program DOES NOT pull from the custom sequences for Ocarina Songs, even when "Ocarina Songs as Fanfares" is checked.

-Fanfare Shuffle pulls about 15 sequences to randomize. OoT has 17 vanilla fanfare sequences (excluding the 10 ocarina songs, otherwise this number is 27).

-BGM Shuffle pulls about 46 sequences to randomize. OoT has 59 vanilla sequences (excluding all 22 Hyrule Field slots, otherwise this number is 81). 